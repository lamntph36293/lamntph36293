/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.MMT_Shop.Lam;

import com.MMT_Shop.EnTiTy.SanPhamCT;
import com.MMT_Shop.swing.ScrollBar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.time.LocalDate;
import java.util.Random;
import javax.swing.table.TableModel;
import java.text.DecimalFormat;
import java.math.RoundingMode;

/**
 *
 * @author pc
 */
public class Form_Voucher extends javax.swing.JPanel {

    DefaultTableModel model = new DefaultTableModel();
    private final QlGiamGia ql = new QlGiamGia();
    ArrayList<TTin> list = new ArrayList<>();
    String ma;

    public Form_Voucher() {

        initComponents();
        model = (DefaultTableModel) tblVou.getModel();
        loadData();
        taoMa();
        txtMa.setText(ma);
    }

    private void taoMa() {
        Random random = new Random();

        for (int i = 0; i < 10; i++) {

            int x = random.nextInt(900) + 10;
            ma = "VO" + x;
            System.out.println(ma);
            txtMa.setText(ma);
        }
    }

    private void loadData() {
        list = ql.data();
        DefaultTableModel model = (DefaultTableModel) tblVou.getModel();
        model.setRowCount(0);

        int count = 1;
        DecimalFormat decimalFormat = new DecimalFormat("#");
        decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
        jScrollPane1.setVerticalScrollBar(new ScrollBar());
        for (int i = list.size() - 1; i >= 0; i--) {
            TTin t = list.get(i);
            model.addRow(new Object[]{
                count,
                t.getMa(),
                t.getTen(),
                t.getNgayBatDau(),
                t.getNgayKetThuc(),
                decimalFormat.format(Math.round(t.getSoLuong())),
                t.getTrangThai(),
                decimalFormat.format(Math.round(t.getPhanTramGiam())),
                decimalFormat.format(Math.round(t.getGiaTriHoaDonToiThieu())),
                decimalFormat.format(Math.round(t.getSoTienGiamToiDa())),
                t.getCreated_At(),
                t.getUpdated_At(),
                t.getCreated_By(),
                t.getUpdated_By()
            });
            count++;
        }

        model.fireTableDataChanged();
        tblVou.setModel(model);

    }

    public TTin getmodel() {
        TTin tt = new TTin();

        tt.setMa(txtMa.getText());
        tt.setTen(txtTen.getText());
        String ngayBatDau = ChuyenDoi.layNgayString(dcsNgayBatDau.getDate());
        tt.setNgayBatDau(ngayBatDau);
        String ngayKet = ChuyenDoi.layNgayString(dcsNgayKet.getDate());
        tt.setNgayKetThuc(ngayKet);

        LocalDate ngayTao = LocalDate.now();
        String ngayTaoString = ngayTao.toString();
        tt.setCreated_At(ngayTao.toString());

        LocalDate ngayUpdate = LocalDate.now();
        String ngayUpdateString = ngayUpdate.toString();
        tt.setUpdated_At(ngayUpdate.toString());

        tt.setTrangThai(txtTrangThai.getText());
        tt.setSoLuong(Integer.valueOf(txtSoLuong.getText()));
        tt.setCreated_By("NV01");
        tt.setUpdated_By("NV01");
        tt.setGiaTriHoaDonToiThieu(Integer.valueOf(txtHoaDonTT.getText()));
        tt.setPhanTramGiam(Integer.valueOf(txtPhanTram.getText()));
        tt.setSoTienGiamToiDa(Integer.valueOf(txtTienGiamTD.getText()));
        return tt;
    }

    private void check() {
        TTin tt = new TTin();

        String ten = txtMa.getText();
        if (ten.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên");
            txtMa.requestFocus();

        }
        tt.setTen(ten);

        String ngayBatDau = ChuyenDoi.layNgayString(dcsNgayBatDau.getDate());
        if (ngayBatDau.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ngày bắt đầu");
            dcsNgayBatDau.requestFocus();

        }
        tt.setNgayBatDau(ngayBatDau);

        String ngayKet = ChuyenDoi.layNgayString(dcsNgayKet.getDate());
        if (ngayKet.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ngày kết thúc");
            dcsNgayKet.requestFocus();

        }
        tt.setNgayKetThuc(ngayKet);

        LocalDate ngayTao = LocalDate.now();
        tt.setCreated_At(ngayTao.toString());

        LocalDate ngayUpdate = LocalDate.now();
        tt.setUpdated_At(ngayUpdate.toString());

        try {
            int soLuong = Integer.parseInt(txtSoLuong.getText());
            tt.setSoLuong(soLuong);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số lượng hợp lệ");
            txtSoLuong.requestFocus();

        }

        try {
            int hoaDonTT = Integer.parseInt(txtHoaDonTT.getText());
            tt.setGiaTriHoaDonToiThieu(hoaDonTT);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập giá trị hóa đơn tối thiểu hợp lệ");
            txtHoaDonTT.requestFocus();

        }

        try {
            int phanTram = Integer.parseInt(txtPhanTram.getText());
            tt.setPhanTramGiam(phanTram);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập phần trăm giảm hợp lệ");
            txtPhanTram.requestFocus();

        }

        try {
            int tienGiamTD = Integer.parseInt(txtTienGiamTD.getText());
            tt.setSoTienGiamToiDa(tienGiamTD);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số tiền giảm tối đa hợp lệ");
            txtTienGiamTD.requestFocus();

        }

    }

    private void insert() {
        TTin tt = getmodel();
        try {
            LocalDate ngayTao = LocalDate.now();
            String ngayTaoString = ngayTao.toString();
            String ngayBatDau = ChuyenDoi.layNgayString(dcsNgayBatDau.getDate());
            String ngayKet = ChuyenDoi.layNgayString(dcsNgayKet.getDate());

            if (ngayBatDau.compareTo(ngayTaoString) < 0 && ngayKet.compareTo(ngayTaoString) > 0) {
                tt.setTrangThai("Đang diễn ra");
            } else if (ngayBatDau.compareTo(ngayTaoString) > 0 && ngayKet.compareTo(ngayBatDau) > 0) {
                tt.setTrangThai("Chuẩn bị diễn ra");
            } else if (ngayBatDau.compareTo(ngayTaoString) < 0 && ngayKet.compareTo(ngayTaoString) < 0) {
                tt.setTrangThai("Quá hạn");
            } else {
                tt.setTrangThai("");
            }

            if (ql.adddata(tt) != null) {
                JOptionPane.showMessageDialog(this, "Thêm thành công, ma: " + tt.getMa());
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi thêm dữ liệu");
        }
    }

    private void click() {
        TableModel table = tblVou.getModel();
        int row = tblVou.getSelectedRow();
        txtMa.setText(tblVou.getValueAt(row, 1).toString());
        txtTen.setText(tblVou.getValueAt(row, 2).toString());
        try {
            int srow = tblVou.getSelectedRow();
            String ngayBatDauString = (String) table.getValueAt(srow, 3);
            Date ngayBatDau = new SimpleDateFormat("yyyy-MM-dd").parse(ngayBatDauString);
            dcsNgayBatDau.setDate(ngayBatDau);

            String ngayKetString = (String) table.getValueAt(srow, 4);
            Date ngayKet = new SimpleDateFormat("yyyy-MM-dd").parse(ngayKetString);
            dcsNgayKet.setDate(ngayKet);

            String ngayTaoString = (String) table.getValueAt(srow, 10);
            Date ngayTao = new SimpleDateFormat("yyyy-MM-dd").parse(ngayTaoString);
            dcsNgayTao.setDate(ngayTao);

            String ngayUpdateString = (String) table.getValueAt(srow, 11);
            Date ngayUpdate = new SimpleDateFormat("yyyy-MM-dd").parse(ngayUpdateString);
            dcsNgayUpdate.setDate(ngayUpdate);

            txtSoLuong.setText(tblVou.getValueAt(row, 5).toString());
            txtTrangThai.setText(tblVou.getValueAt(row, 6).toString());
            txtPhanTram.setText(tblVou.getValueAt(row, 7).toString());
            txtHoaDonTT.setText(tblVou.getValueAt(row, 8).toString());
            txtTienGiamTD.setText(tblVou.getValueAt(row, 9).toString());

        } catch (Exception e) {
        }
        tblVou.getSelectionModel().addSelectionInterval(row, row);
    }

    private void update() {
        TTin tt = getmodel();
        try {
            LocalDate ngayTao = LocalDate.now();
            String ngayTaoString = ngayTao.toString();
            String ngayBatDau = ChuyenDoi.layNgayString(dcsNgayBatDau.getDate());
            String ngayKet = ChuyenDoi.layNgayString(dcsNgayKet.getDate());

            if (ngayBatDau.compareTo(ngayTaoString) < 0 && ngayKet.compareTo(ngayTaoString) > 0) {
                tt.setTrangThai("Đang diễn ra");
            } else if (ngayBatDau.compareTo(ngayTaoString) > 0 && ngayKet.compareTo(ngayBatDau) > 0) {
                tt.setTrangThai("Chuẩn bị diễn ra");
            } else if (ngayBatDau.compareTo(ngayTaoString) < 0 && ngayKet.compareTo(ngayTaoString) < 0) {
                tt.setTrangThai("Quá hạn");
            } else {
                tt.setTrangThai("");
            }
            if (ql.updatedata(tt) != null) {
                JOptionPane.showMessageDialog(this, "sửa thanh cong");
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "sửa that bai");

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, " loi nut sửa");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        btnThem = new com.MMT_Shop.swing.button.Button();
        btnXoa = new com.MMT_Shop.swing.button.Button();
        btnNew = new com.MMT_Shop.swing.button.Button();
        btnUpdate = new com.MMT_Shop.swing.button.Button();
        txtHoaDonTT = new com.MMT_Shop.swing.textfield.TextField();
        txtPhanTram = new com.MMT_Shop.swing.textfield.TextField();
        txtTienGiamTD = new com.MMT_Shop.swing.textfield.TextField();
        txtTen = new com.MMT_Shop.swing.textfield.TextField();
        txtMa = new com.MMT_Shop.swing.textfield.TextField();
        txtSoLuong = new com.MMT_Shop.swing.textfield.TextField();
        jPanel1 = new javax.swing.JPanel();
        dcsNgayBatDau = new com.toedter.calendar.JDateChooser();
        jPanel2 = new javax.swing.JPanel();
        dcsNgayTao = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        dcsNgayKet = new com.toedter.calendar.JDateChooser();
        jPanel5 = new javax.swing.JPanel();
        dcsNgayUpdate = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        txtTimKiem = new com.MMT_Shop.swing.textfield.TextField();
        txtTrangThai = new com.MMT_Shop.swing.textfield.TextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVou = new com.MMT_Shop.swing.Table();

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Chương trình giảm giá", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jPanel12.setForeground(new java.awt.Color(255, 255, 255));

        btnThem.setBackground(new java.awt.Color(172, 182, 229));
        btnThem.setForeground(new java.awt.Color(245, 245, 245));
        btnThem.setText("Thêm");
        btnThem.setRippleColor(new java.awt.Color(255, 255, 255));
        btnThem.setShadowColor(new java.awt.Color(172, 182, 229));
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnXoa.setBackground(new java.awt.Color(172, 182, 229));
        btnXoa.setForeground(new java.awt.Color(245, 245, 245));
        btnXoa.setText("Xóa ");
        btnXoa.setRippleColor(new java.awt.Color(255, 255, 255));
        btnXoa.setShadowColor(new java.awt.Color(172, 182, 229));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnNew.setBackground(new java.awt.Color(172, 182, 229));
        btnNew.setForeground(new java.awt.Color(245, 245, 245));
        btnNew.setText("Làm mới ");
        btnNew.setRippleColor(new java.awt.Color(255, 255, 255));
        btnNew.setShadowColor(new java.awt.Color(172, 182, 229));
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });

        btnUpdate.setBackground(new java.awt.Color(172, 182, 229));
        btnUpdate.setForeground(new java.awt.Color(245, 245, 245));
        btnUpdate.setText("Sửa");
        btnUpdate.setRippleColor(new java.awt.Color(255, 255, 255));
        btnUpdate.setShadowColor(new java.awt.Color(172, 182, 229));
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        txtHoaDonTT.setLabelText("Hóa đơn tối thiểu");

        txtPhanTram.setLabelText("Phần trăm giảm");

        txtTienGiamTD.setLabelText("Số tiền Giảm tối đa");

        txtTen.setLabelText("Tên khuyến mãi ");

        txtMa.setEditable(false);
        txtMa.setBackground(new java.awt.Color(255, 255, 255));
        txtMa.setLabelText("Mã khuyến mãi");

        txtSoLuong.setLabelText("Số lượng ");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Ngày bắt đầu", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 10))); // NOI18N
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));
        jPanel1.add(dcsNgayBatDau);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Ngày tạo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 10))); // NOI18N
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));
        jPanel2.add(dcsNgayTao);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Ngày kết thúc", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 10))); // NOI18N
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.LINE_AXIS));
        jPanel3.add(dcsNgayKet);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Ngày sửa", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 10))); // NOI18N
        jPanel5.setLayout(new javax.swing.BoxLayout(jPanel5, javax.swing.BoxLayout.LINE_AXIS));
        jPanel5.add(dcsNgayUpdate);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtTienGiamTD, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE)
                            .addComponent(txtPhanTram, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtHoaDonTT, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNew, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(txtHoaDonTT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(4, 4, 4)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPhanTram, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(txtTienGiamTD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Danh sách KM"));

        txtTimKiem.setLabelText("Tìm kiếm theo các trường");
        txtTimKiem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemMouseClicked(evt);
            }
        });
        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        txtTrangThai.setEditable(false);
        txtTrangThai.setBackground(new java.awt.Color(255, 255, 255));
        txtTrangThai.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtTrangThai.setLabelText("Trạng thái");
        txtTrangThai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTrangThaiMouseClicked(evt);
            }
        });
        txtTrangThai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTrangThaiActionPerformed(evt);
            }
        });

        tblVou.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã", "Tên ", "Ngày BD", "Ngày KT", "Số lượng", "Trạng thái ", "% Giảm", "Hóa đơn tối thiểu ", "Só tiền giảm tối đa", "Ngày tạo", "Ngày sửa", "Người tạo", "Ngươì sửa"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblVou.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblVouMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblVou);
        if (tblVou.getColumnModel().getColumnCount() > 0) {
            tblVou.getColumnModel().getColumn(0).setPreferredWidth(50);
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtTrangThai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemSP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSP1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThemSP1ActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        getmodel();
        check();
        insert();
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        int chon = JOptionPane.showConfirmDialog(this, "ban muon xoa khong");

        if (chon == 0) {
            ql.DeleteData(txtMa.getText());
            JOptionPane.showMessageDialog(this, "xoa thanh cong");
            loadData();
            resetForm();
        } else {
            JOptionPane.showMessageDialog(this, "khong xoa");
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
        resetForm();
    }//GEN-LAST:event_btnNewActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        update();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtTimKiemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemMouseClicked
        DefaultTableModel ob = (DefaultTableModel) tblVou.getModel();
        TableRowSorter<DefaultTableModel> obj = new TableRowSorter<>(ob);
        tblVou.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(txtTimKiem.getText()));
    }//GEN-LAST:event_txtTimKiemMouseClicked

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void txtTrangThaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTrangThaiMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTrangThaiMouseClicked

    private void txtTrangThaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTrangThaiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTrangThaiActionPerformed

    private void tblVouMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblVouMouseClicked
        click();
    }//GEN-LAST:event_tblVouMouseClicked
    private void resetForm() {
        taoMa();
        txtTen.setText("");
        dcsNgayBatDau.setDate(null);
        dcsNgayKet.setDate(null);
        dcsNgayTao.setDate(null);
        dcsNgayUpdate.setDate(null);
        txtSoLuong.setText("");
        txtTrangThai.setText("");
        txtPhanTram.setText("");
        txtHoaDonTT.setText("");
        txtTienGiamTD.setText("");
        tblVou.clearSelection();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.MMT_Shop.swing.button.Button btnNew;
    private com.MMT_Shop.swing.button.Button btnThem;
    private com.MMT_Shop.swing.button.Button btnUpdate;
    private com.MMT_Shop.swing.button.Button btnXoa;
    private com.toedter.calendar.JDateChooser dcsNgayBatDau;
    private com.toedter.calendar.JDateChooser dcsNgayKet;
    private com.toedter.calendar.JDateChooser dcsNgayTao;
    private com.toedter.calendar.JDateChooser dcsNgayUpdate;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private com.MMT_Shop.swing.Table tblVou;
    private com.MMT_Shop.swing.textfield.TextField txtHoaDonTT;
    private com.MMT_Shop.swing.textfield.TextField txtMa;
    private com.MMT_Shop.swing.textfield.TextField txtPhanTram;
    private com.MMT_Shop.swing.textfield.TextField txtSoLuong;
    private com.MMT_Shop.swing.textfield.TextField txtTen;
    private com.MMT_Shop.swing.textfield.TextField txtTienGiamTD;
    private com.MMT_Shop.swing.textfield.TextField txtTimKiem;
    private com.MMT_Shop.swing.textfield.TextField txtTrangThai;
    // End of variables declaration//GEN-END:variables
}
