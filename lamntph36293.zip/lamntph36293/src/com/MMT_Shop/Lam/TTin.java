/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.MMT_Shop.Lam;

import java.util.Date;

/**
 *
 * @author admin
 */
public class TTin {
    private int id;
    private String ma;
    private String ten;
    private String ngayBatDau;
    private String ngayKetThuc;
    private int soLuong;
    private String trangThai;
    private double phanTramGiam;
    private double giaTriHoaDonToiThieu;
    private double soTienGiamToiDa;
    private String created_At;
    private String updated_At;
    private String created_By;
    private String updated_By;

    public TTin() {
    }

    public TTin(int id, String ma, String ten, String ngayBatDau, String ngayKetThuc, int soLuong, String trangThai, double phanTramGiam, double giaTriHoaDonToiThieu, double soTienGiamToiDa, String created_At, String updated_At, String created_By, String updated_By) {
        this.id = id;
        this.ma = ma;
        this.ten = ten;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.soLuong = soLuong;
        this.trangThai = trangThai;
        this.phanTramGiam = phanTramGiam;
        this.giaTriHoaDonToiThieu = giaTriHoaDonToiThieu;
        this.soTienGiamToiDa = soTienGiamToiDa;
        this.created_At = created_At;
        this.updated_At = updated_At;
        this.created_By = created_By;
        this.updated_By = updated_By;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(String ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public String getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(String ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public double getPhanTramGiam() {
        return phanTramGiam;
    }

    public void setPhanTramGiam(double phanTramGiam) {
        this.phanTramGiam = phanTramGiam;
    }

    public double getGiaTriHoaDonToiThieu() {
        return giaTriHoaDonToiThieu;
    }

    public void setGiaTriHoaDonToiThieu(double giaTriHoaDonToiThieu) {
        this.giaTriHoaDonToiThieu = giaTriHoaDonToiThieu;
    }

    public double getSoTienGiamToiDa() {
        return soTienGiamToiDa;
    }

    public void setSoTienGiamToiDa(double soTienGiamToiDa) {
        this.soTienGiamToiDa = soTienGiamToiDa;
    }

    public String getCreated_At() {
        return created_At;
    }

    public void setCreated_At(String created_At) {
        this.created_At = created_At;
    }

    public String getUpdated_At() {
        return updated_At;
    }

    public void setUpdated_At(String updated_At) {
        this.updated_At = updated_At;
    }

    public String getCreated_By() {
        return created_By;
    }

    public void setCreated_By(String created_By) {
        this.created_By = created_By;
    }

    public String getUpdated_By() {
        return updated_By;
    }

    public void setUpdated_By(String updated_By) {
        this.updated_By = updated_By;
    }

    
    
    
    

   
    
    
    }


    

    
    
    
   

    
    

