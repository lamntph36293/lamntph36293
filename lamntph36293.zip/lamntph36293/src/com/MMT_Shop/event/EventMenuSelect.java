package com.MMT_Shop.event;

public interface EventMenuSelect {

    public void selected(int index);

}
