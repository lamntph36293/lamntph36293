package com.MMT_Shop.event;

import com.MMT_Shop.swing.FormOfFhoice.BreadcrumbItem;

public interface EventItemSelected {

    public void selected(BreadcrumbItem item);
}
