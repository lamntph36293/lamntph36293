package com.MMT_Shop.model;

public enum StatusType {
    // dùng để hiển thị hàng còn hay hết hay sắp hết 
    
    //PENDING, APPROVED, REJECT
    CON, SAPHET, HET
}
