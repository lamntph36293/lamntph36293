
package com.MMT_Shop.model;

public class Model_QRCode {
    
}
