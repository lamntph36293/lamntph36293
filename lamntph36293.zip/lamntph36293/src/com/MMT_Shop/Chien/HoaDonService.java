package com.MMT_Shop.Chien;

import com.MMT_Shop.Tung.KhachHang;
import com.MMT_Shop.utility.DBcontext;
import java.sql.*;
import java.util.ArrayList;

public class HoaDonService {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;

    public float tongTien(String ma) {
        float sl = 0;
        String Selete_All_sql = "select sum(thanhTien) as 'tongtien' from HoaDonChiTiet where hoaDonID =(select id from HoaDon where ma like ?)";
        Connection cn = DBcontext.getConnection();
        try {
            PreparedStatement ps = cn.prepareStatement(Selete_All_sql);
            ps.setString(1, ma);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                sl = rs.getFloat("tongtien");
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return sl;

    }

    public Integer InsertHD(HoaDon h) {
        Integer row = null;
        String Insert_sql = "insert into HoaDon (ma,nhanVienID,soDienThoai,tenKhachHang,trangThai,Created_At,Updated_At,Created_By,Updated_By,Deleted,tongTien)\n"
                + "values (?,(select id from NhanVien where ma like ?),?,?,?,?,?,?,?,?,?)";
        Connection cn = DBcontext.getConnection();
        try {
            PreparedStatement ps = cn.prepareStatement(Insert_sql);
            ps.setString(1, h.getMaHD());
            ps.setString(2, h.getMaNV());
            ps.setString(3, h.getSdt());
            ps.setString(4, h.getTenKH());
            ps.setString(5, h.getTrangThai());
            ps.setString(6, h.getCreated_At());
            ps.setString(7, h.getUpdated_At());
            ps.setString(8, h.getCreated_By());
            ps.setString(9, h.getUpdated_By());
            ps.setString(10, h.getDeleted());
            ps.setFloat(11, h.getTongTien());

            row = ps.executeUpdate();
        } catch (Exception e) {
            System.out.print(e);
        }
        return row;
    }

    public Integer InsertHDCT(HoaDonChiTiet h) {
        Integer row = null;
        String Insert_sql = "insert into HoaDonChiTiet(hoaDonID,chiTietSanPhamID,ma,gia,soLuong,thanhTien,Created_At,Updated_At,Created_By,Updated_By,Deleted)\n"
                + "values ((select id from HoaDon where ma like ?),\n"
                + "(select id from CTSP where maCTSP like ?),\n"
                + "?,?,?,?,?,?,?,?,?)";
        Connection cn = DBcontext.getConnection();
        try {
            PreparedStatement ps = cn.prepareStatement(Insert_sql);
            ps.setString(1, h.getMaHD());
            ps.setString(2, h.getMaCTSP());
            ps.setString(3, h.getMaHDCT());
            ps.setFloat(4, h.getGia());
            ps.setInt(5, h.getSoLuong());
            ps.setFloat(6, h.getThanhTien());
            ps.setString(7, h.getCreated_At());
            ps.setString(8, h.getUpdated_At());
            ps.setString(9, h.getCreated_By());
            ps.setString(10, h.getUpdated_By());
            ps.setString(11, h.getDeleted());
            row = ps.executeUpdate();
        } catch (Exception e) {
            System.out.print(e);
        }
        return row;
    }

    public Integer updateHDCT(HoaDonChiTiet h) {
        Integer row = null;
        String Insert_sql = "update HoaDonChiTiet set soLuong= ?, thanhTien  = ? where ma like ?";
        Connection cn = DBcontext.getConnection();
        try {
            PreparedStatement ps = cn.prepareStatement(Insert_sql);
            ps.setInt(1, h.getSoLuong());
            ps.setFloat(2, h.getThanhTien());
            ps.setString(3, h.getMaHDCT());
            row = ps.executeUpdate();
        } catch (Exception e) {
            System.out.print(e);
        }
        return row;
    }

    public Integer deletedHDCT(HoaDonChiTiet h) {
        Integer row = null;
        String Insert_sql = "delete HoaDonChiTiet where ma like ?";
        Connection cn = DBcontext.getConnection();
        try {
            PreparedStatement ps = cn.prepareStatement(Insert_sql);
            ps.setString(1, h.getMaHDCT());
            row = ps.executeUpdate();
        } catch (Exception e) {
            System.out.print(e);
        }
        return row;
    }

    public ArrayList<HoaDon> getAllHoaDon() {
        ArrayList<HoaDon> listHD = new ArrayList<>();
        sql = "SELECT HoaDon.id as 'idHD',  HoaDon.ma as 'maHD', NhanVien.ma as 'maNV', NhanVien.Ten as 'tenNV',\n"
                + "KhachHang.ma as 'maKH',tenKhachHang,Voucher.ma as 'maVoucher',HoaDon.trangThai as 'trangThaiHD',\n"
                + "ngayGiaoDich,ngayHoanThanh,HoaDon.diaChi as 'diaChi',HoaDon.soDienThoai as 'SDT',tongTien,\n"
                + "HoaDon.Created_At as 'Created_At',HoaDon.Updated_At as 'Updated_At', HoaDon.Created_By as 'Created_By',\n"
                + "HoaDon.Updated_By as 'Updated_By', HoaDon.Deleted as 'Deleted' FROM HoaDon\n"
                + "left join NhanVien on HoaDon.NhanVienID = NhanVien.id \n"
                + "left join Voucher on HoaDon.VoucherID = Voucher.id \n"
                + "left join KhachHang on HoaDon.khacHangID = KhachHang.id";

        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("idHD"));
                hd.setMaHD(rs.getString("maHD"));
                hd.setMaNV(rs.getString("maNV"));
                hd.setTenNV(rs.getString("tenNV"));
                hd.setMaKH(rs.getString("maKH"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setVoucher(rs.getString("maVoucher"));
                hd.setTrangThai(rs.getString("trangThaiHD"));
                hd.setNgayGiaoDich(rs.getString("ngayGiaoDich"));
                hd.setNgayHoanThanh(rs.getString("ngayHoanThanh"));
                hd.setDiaChi(rs.getString("diaChi"));
                hd.setSdt(rs.getString("SDT"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listHD.add(hd);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return listHD;
    }

    public ArrayList<HoaDon> getHDTheoMa(String maHD) {
        ArrayList<HoaDon> listHD = new ArrayList<>();
        sql = "SELECT HoaDon.id as 'idHD',  HoaDon.ma as 'maHD', NhanVien.ma as 'maNV', NhanVien.Ten as 'tenNV',\n"
                + "KhachHang.ma as 'maKH',tenKhachHang,Voucher.ma as 'maVoucher',HoaDon.trangThai as 'trangThaiHD',\n"
                + "ngayGiaoDich,ngayHoanThanh,HoaDon.diaChi as 'diaChi',HoaDon.soDienThoai as 'SDT',tongTien,\n"
                + "HoaDon.Created_At as 'Created_At',HoaDon.Updated_At as 'Updated_At', HoaDon.Created_By as 'Created_By',\n"
                + "HoaDon.Updated_By as 'Updated_By', HoaDon.Deleted as 'Deleted' FROM HoaDon\n"
                + "left join NhanVien on HoaDon.NhanVienID = NhanVien.id \n"
                + "left join Voucher on HoaDon.VoucherID = Voucher.id \n"
                + "left join KhachHang on HoaDon.khacHangID = KhachHang.id\n"
                + "where HoaDon.ma like ?";

        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, maHD);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("idHD"));
                hd.setMaHD(rs.getString("maHD"));
                hd.setMaNV(rs.getString("maNV"));
                hd.setTenNV(rs.getString("tenNV"));
                hd.setMaKH(rs.getString("maKH"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setVoucher(rs.getString("maVoucher"));
                hd.setTrangThai(rs.getString("trangThaiHD"));
                hd.setNgayGiaoDich(rs.getString("ngayGiaoDich"));
                hd.setNgayHoanThanh(rs.getString("ngayHoanThanh"));
                hd.setDiaChi(rs.getString("diaChi"));
                hd.setSdt(rs.getString("SDT"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listHD.add(hd);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return listHD;
    }

    public ArrayList<HoaDon> timKiem(String maTimKiem) {
        ArrayList<HoaDon> listTimKiem = new ArrayList<>();
        sql = "SELECT id, HoaDon.ma, HoaDon.tenKhachHang, HoaDon.soDienThoai,HoaDon.ngayHoanThanh, HoaDon.trangThai,\n"
                + "HoaDon.Created_At, HoaDon.diaChi, HoaDon.tongTien, HoaDon.Updated_At, HoaDon.Created_By, HoaDon.Updated_By, HoaDon.Deleted "
                + "FROM HoaDon WHERE ma like ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, maTimKiem);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("id"));
                hd.setMaHD(rs.getString("ma"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setSdt(rs.getString("soDienThoai"));
                hd.setNgayGiaoDich(rs.getString("Created_At"));
                hd.setNgayHoanThanh("ngayHoanThanh");
                hd.setTrangThai(rs.getString("trangThai"));
                hd.setDiaChi(rs.getString("diaChi"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listTimKiem.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listTimKiem;
    }

    public ArrayList<HoaDon> timKiemTheoNgay(String ngayBD, String ngayKT) {
        ArrayList<HoaDon> listTimKiem = new ArrayList<>();
        sql = "SELECT id, HoaDon.ma, HoaDon.tenKhachHang, HoaDon.soDienThoai,HoaDon.ngayHoanThanh, HoaDon.trangThai,\n"
                + "HoaDon.Created_At, HoaDon.diaChi, HoaDon.tongTien, HoaDon.Updated_At, HoaDon.Created_By, HoaDon.Updated_By, HoaDon.Deleted "
                + "FROM HoaDon WHERE ngayGiaoDich BETWEEN ? and ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, ngayBD);
            ps.setString(2, ngayKT);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("id"));
                hd.setMaHD(rs.getString("ma"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setSdt(rs.getString("soDienThoai"));
                hd.setNgayGiaoDich(rs.getString("Created_At"));
                hd.setNgayHoanThanh("ngayHoanThanh");
                hd.setTrangThai(rs.getString("trangThai"));
                hd.setDiaChi(rs.getString("diaChi"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listTimKiem.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listTimKiem;
    }

    public ArrayList<HoaDon> timKiemHoaDon(String str) {
        ArrayList<HoaDon> listTimKiemHD = new ArrayList<>();
        sql = "SELECT HoaDon.id as 'HoaDon',  HoaDon.ma as 'maHD',\n"
                + "NhanVien.ma as 'NhanVien', tenKhachHang, HoaDon.soDienThoai,\n"
                + "tongTien, HoaDon.Created_At, HoaDon.trangThai,\n"
                + "HoaDon.Updated_At, HoaDon.Created_By, HoaDon.Updated_By, HoaDon.Deleted FROM HoaDon\n"
                + "left join NhanVien on HoaDon.NhanVienID = NhanVien.id\n"
                + "WHERE HoaDon.ma LIKE ? OR HoaDon.soDienThoai LIKE ? OR tenKhachHang LIKE ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, str);
            ps.setString(2, str);
            ps.setString(3, str);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getString("maHD"));
                hd.setMaNV(rs.getString("NhanVien"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setSdt(rs.getString("soDienThoai"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setNgayGiaoDich(rs.getString("Created_At"));
                hd.setTrangThai(rs.getString("trangThai"));
                listTimKiemHD.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listTimKiemHD;
    }

    public ArrayList<HoaDonChiTiet> lienKetHoaDon(String maTK) {
        ArrayList<HoaDonChiTiet> listLienKetHD = new ArrayList<>();
        sql = "select HoaDonChiTiet.id as 'id', HoaDonChiTiet.ma as 'maHDCT',CTSP.maCTSP as 'maCTSP',\n"
                + "SanPham.ten as'tensp',ThuongHieu.ten as 'hang',MauSac.ten as 'mau',\n"
                + "HoaDonChiTiet.soLuong as 'soluong', HoaDonChiTiet.gia as 'gia',HoaDonChiTiet.thanhTien as 'thanhTien'\n"
                + "from HoaDonChiTiet \n"
                + "left join HoaDon on HoaDon.id= HoaDonChiTiet.hoaDonID\n"
                + "left join CTSP on CTSP.id = HoaDonChiTiet.chiTietSanPhamID \n"
                + "left join SanPham on sanPham.id = CTSP.sanPhamID\n"
                + "left join ThuongHieu on ThuongHieu.id = CTSP.thuongHieuID \n"
                + "left join MauSac on MauSac.id = CTSP.mauSacID\n"
                + "where HoaDon.ma like ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, maTK);
            rs = ps.executeQuery();
            while (rs.next()) {
//                listLienKetHD.add(new HoaDonChiTiet(rs.getInt("id"), rs.getString("maCTSP"), rs.getString("tensp"), rs.getInt("soLuong"), rs.getFloat("gia"), rs.getFloat("thanhTien"), rs.getString("hang"), rs.getString("mau"), maTK, maTK, maTK, maTK, maTK));
                HoaDonChiTiet hdct = new HoaDonChiTiet();
                hdct.setTenSP(rs.getString("tensp"));
                hdct.setMaHDCT(rs.getString("maHDCT"));
                hdct.setMaCTSP(rs.getString("maCTSP"));
                hdct.setHang(rs.getString("hang"));
                hdct.setMauSac(rs.getString("mau"));
                hdct.setSoLuong(rs.getInt("soluong"));
                hdct.setGia(rs.getFloat("gia"));
                hdct.setThanhTien(rs.getFloat("thanhTien"));
                listLienKetHD.add(hdct);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listLienKetHD;
    }

    public ArrayList<HoaDon> lienKetHoaDon1(String ma) {
        ArrayList<HoaDon> listLKHD1 = new ArrayList<>();
        sql = "SELECT ma, ngayHoanThanh, trangThai\n"
                + "FROM HoaDon\n"
                + "WHERE ma like ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, ma);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaNV(rs.getString("ma"));
                hd.setNgayHoanThanh(rs.getString("ngayHoanThanh"));
                hd.setTrangThai(rs.getString("trangThai"));
                listLKHD1.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listLKHD1;
    }

    public ArrayList<HoaDon> locTrangThaiHD(String trangThai) {
        ArrayList<HoaDon> listLocTrangThai = new ArrayList<>();
        sql = "SELECT HoaDon.id as 'HoaDon',  HoaDon.ma as 'maHD',\n"
                + "NhanVien.ma as 'NhanVien', tenKhachHang, HoaDon.soDienThoai,\n"
                + "tongTien, HoaDon.Created_At, HoaDon.trangThai,\n"
                + "HoaDon.Updated_At, HoaDon.Created_By, HoaDon.Updated_By, HoaDon.Deleted FROM HoaDon\n"
                + "left join NhanVien on HoaDon.NhanVienID = NhanVien.id\n"
                + "WHERE HoaDon.trangThai = ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, trangThai);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("HoaDon"));
                hd.setMaHD(rs.getString("maHD"));
                hd.setMaNV(rs.getString("NhanVien"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setSdt(rs.getString("soDienThoai"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setNgayGiaoDich(rs.getString("Created_At"));
                hd.setTrangThai(rs.getString("trangThai"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listLocTrangThai.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listLocTrangThai;
    }

    public ArrayList<HoaDon> locHinhThucTTHD(String hinhThuc) {
        ArrayList<HoaDon> listHinhThucTT = new ArrayList<>();
        sql = "SELECT HoaDon.id as 'HoaDon',  HoaDon.ma as 'maHD',\n"
                + "NhanVien.ma as 'NhanVien', tenKhachHang, HoaDon.soDienThoai,\n"
                + "tongTien, HoaDon.Created_At, HoaDon.trangThai,\n"
                + "HoaDon.Updated_At, HoaDon.Created_By, HoaDon.Updated_By, HoaDon.Deleted,\n"
                + "HInhThucThanhToan.hinhThucThanhToan as 'hinhThuc'\n"
                + "FROM HoaDon\n"
                + "left join NhanVien on HoaDon.NhanVienID = NhanVien.id\n"
                + "left join CTHTThanhToan on HoaDon.CTHTThanhToanID =CTHTThanhToan.id\n"
                + "left join HInhThucThanhToan on CTHTThanhToan.hinhThucThanhToanID =  hinhThucThanhToan.id \n"
                + "WHERE hinhThucThanhToan = ?";
        try {
            con = DBcontext.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, hinhThuc);
            rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setId(rs.getInt("HoaDon"));
                hd.setMaHD(rs.getString("maHD"));
                hd.setMaNV(rs.getString("NhanVien"));
                hd.setTenKH(rs.getString("tenKhachHang"));
                hd.setSdt(rs.getString("soDienThoai"));
                hd.setTongTien(rs.getFloat("tongTien"));
                hd.setNgayGiaoDich(rs.getString("Created_At"));
                hd.setTrangThai(rs.getString("trangThai"));
                hd.setHinhThucThanhToan(rs.getString("hinhThuc"));
                hd.setCreated_At(rs.getString("Created_At"));
                hd.setUpdated_At(rs.getString("Updated_At"));
                hd.setCreated_By(rs.getString("Created_By"));
                hd.setUpdated_By(rs.getString("Updated_By"));
                hd.setDeleted(rs.getString("Deleted"));
                listHinhThucTT.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listHinhThucTT;
    }
}
