package com.MMT_Shop.form;

import com.MMT_Shop.Chien.HoaDon;
import com.MMT_Shop.Chien.HoaDonChiTiet;
import com.MMT_Shop.Dao.HoaDonDAO;
import com.MMT_Shop.Dao.SanPhamDAO;
import com.MMT_Shop.EnTiTy.SanPhamCT;
import com.MMT_Shop.swing.ScrollBar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.ThreadFactory;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Form_Ban_Hang extends javax.swing.JPanel implements Runnable, ThreadFactory {

    private DefaultTableModel model = new DefaultTableModel();
    private ArrayList<SanPhamCT> data = new ArrayList<>();
    private ArrayList<HoaDon> listHD = new ArrayList<>();
    private ArrayList<HoaDonChiTiet> listHDCT = new ArrayList<>();
    private final SanPhamDAO dataSP = new SanPhamDAO();
    private final HoaDonDAO dataHD = new HoaDonDAO();

    String maHD;
    String soLuong;
    String soLuongTon;
    String code;
    String maHDCTMoi;
    String maHDMoi;
    public Form_Ban_Hang() {
        initComponents();
        inti();
    }

    private void inti() {
        addRowTableSPCT();
        addRowTableHD();

    }
    private void taoMa() {
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int x = random.nextInt() + 10;
            if (x < 0) {
                x = x * -1;
            }
            code = x + "";
            maHDMoi = "HD" + code;
            maHDCTMoi = "HDCT" + code;
        }
    }
 private void showMessageBox(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
    private void addRowTableSPCT() {
        model = (DefaultTableModel) tblSPCT.getModel();
        model.setRowCount(0);
        spSPCT.setVerticalScrollBar(new ScrollBar());
        data = dataSP.SelectSanPhamCT1();
        for (int i = data.size() - 1; i >= 0; i--) {
            SanPhamCT sp = data.get(i);
            tblSPCT.addRow(new Object[]{tblSPCT.getRowCount() + 1, sp.getMaSPCT(), sp.getTenSP(),
                sp.getThuongHieu(), sp.getLoaiKhung(), sp.getChatLieu(), sp.getKichThuoc(),
                sp.getMauSac(), sp.getGia(), sp.getSoLuong()});
        }

    }

    private void addRowTableHD() {
        model = (DefaultTableModel) tblHoaDon.getModel();
        model.setRowCount(0);
        spHD.setVerticalScrollBar(new ScrollBar());
        listHD = dataHD.selectALLHD();
        for (int i = listHD.size() - 1; i >= 0; i--) {
            HoaDon hd = listHD.get(i);
            tblHoaDon.addRow(new Object[]{tblHoaDon.getRowCount() + 1, hd.getMaHD(),
                hd.getCreated_At(), hd.getMaNV(), hd.getTenKH(), hd.getTrangThai()});
        }

    }

    public void addRowTableHDCT(String maHD) {
        model = (DefaultTableModel) tblHDCT.getModel();
        model.setRowCount(0);
        spHDCT.setVerticalScrollBar(new ScrollBar());
        listHDCT = dataHD.selectALLHDCT(maHD);
        for (int i = listHDCT.size() - 1; i >= 0; i--) {
            HoaDonChiTiet hdct = listHDCT.get(i);
            model.addRow(new Object[]{
                tblHDCT.getRowCount() + 1,
                hdct.getMaHDCT(),
                hdct.getMaCTSP(),
                hdct.getTenSP(),
                hdct.getHang(),
                hdct.getMauSac(),
                hdct.getSoLuong(),
                hdct.getGia(),
                hdct.getThanhTien(),});
        }

    }

    private void clickHD() {
        int row = tblHoaDon.getSelectedRow();
        String ma = tblHoaDon.getValueAt(row, 1).toString();
        maHD = tblHoaDon.getValueAt(row, 1).toString();
        addRowTableHDCT(maHD);
    }
     private HoaDonChiTiet addHDCT() {
        Date now = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String At = format.format(now);
        //về sau có đăng nhập thì lấy mã nv đang đăng ngập
        String mnv = "NV01";
        HoaDonChiTiet hdct = new HoaDonChiTiet();
        hdct.setMaHDCT(maHDCTMoi);
        hdct.setMaHD(maHD);
        hdct.setMaCTSP(maSPCT);
        hdct.setSoLuong(Integer.valueOf(sl));
        hdct.setGia(Float.valueOf(gia));
        float thanhTien = Integer.valueOf(sl) * Float.valueOf(gia);
        hdct.setThanhTien(thanhTien);
        hdct.setCreated_At(At);
        hdct.setUpdated_At(At);
        hdct.setCreated_By(mnv);
        hdct.setUpdated_By(mnv);
        hdct.setDeleted(mnv);
        return hdct;
    }
    void insertHDCT() {
        HoaDonChiTiet hd = addHDCT();
        try {
            if (serviceHD.InsertHDCT(hd) != null) {
                showMessageBox("Thêm thành công");
                listHDCT = serviceHD.lienKetHoaDon(mahdsd);
                upDatedSPCT();
                addRowTableSPCT();
                fillTableHDCT(listHDCT);
            } else {
                showMessageBox("Thêm thất bại");
            }
        } catch (Exception e) {
            showMessageBox("Lỗi nút thêm");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        spHD = new javax.swing.JScrollPane();
        tblHoaDon = new com.MMT_Shop.swing.Table();
        jPanel6 = new javax.swing.JPanel();
        btnThem3 = new com.MMT_Shop.swing.button.Button();
        jPanel4 = new javax.swing.JPanel();
        spHDCT = new javax.swing.JScrollPane();
        tblHDCT = new com.MMT_Shop.swing.Table();
        btnXoaSP = new com.MMT_Shop.swing.button.Button();
        jPanel5 = new javax.swing.JPanel();
        spSPCT = new javax.swing.JScrollPane();
        tblSPCT = new com.MMT_Shop.swing.Table();
        btnThemSP = new com.MMT_Shop.swing.button.Button();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        btnChoKH = new com.MMT_Shop.swing.button.Button();
        btnThem4 = new com.MMT_Shop.swing.button.Button();
        addKhung = new com.MMT_Shop.swing.button.Button();

        setPreferredSize(new java.awt.Dimension(911, 650));

        jPanel1.setPreferredSize(new java.awt.Dimension(911, 650));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Hóa đơn chờ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã hóa đơn", "Ngày tạo  ", "NV tạo ", "Khách hàng", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHoaDonMouseClicked(evt);
            }
        });
        spHD.setViewportView(tblHoaDon);
        if (tblHoaDon.getColumnModel().getColumnCount() > 0) {
            tblHoaDon.getColumnModel().getColumn(0).setPreferredWidth(30);
            tblHoaDon.getColumnModel().getColumn(3).setPreferredWidth(40);
        }

        btnThem3.setBackground(new java.awt.Color(172, 182, 229));
        btnThem3.setForeground(new java.awt.Color(245, 245, 245));
        btnThem3.setText("Thêm");
        btnThem3.setRippleColor(new java.awt.Color(255, 255, 255));
        btnThem3.setShadowColor(new java.awt.Color(172, 182, 229));
        btnThem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThem3ActionPerformed(evt);
            }
        });
        jPanel6.add(btnThem3);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(spHD, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(spHD, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Giỏ hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        tblHDCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "", "Mã SP ", "Tên SP ", "Hãng ", "Loại khung", "Chất liệu ", "Kích thước ", "Màu sắc ", "Đơn giá ", "Số lượng ", "Thành tiền "
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHDCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHDCTMouseClicked(evt);
            }
        });
        spHDCT.setViewportView(tblHDCT);
        if (tblHDCT.getColumnModel().getColumnCount() > 0) {
            tblHDCT.getColumnModel().getColumn(0).setPreferredWidth(40);
            tblHDCT.getColumnModel().getColumn(1).setMinWidth(0);
            tblHDCT.getColumnModel().getColumn(1).setPreferredWidth(0);
            tblHDCT.getColumnModel().getColumn(1).setMaxWidth(0);
        }

        btnXoaSP.setBackground(new java.awt.Color(172, 182, 229));
        btnXoaSP.setForeground(new java.awt.Color(245, 245, 245));
        btnXoaSP.setText("Xóa sản phẩm");
        btnXoaSP.setRippleColor(new java.awt.Color(255, 255, 255));
        btnXoaSP.setShadowColor(new java.awt.Color(172, 182, 229));
        btnXoaSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaSPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(spHDCT)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnXoaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, 0))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(btnXoaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(spHDCT, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Danh sách sản phẩm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        tblSPCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "STT", "Mã SP chi tiết", "Tên SP", "Hãng ", "Loại khung", "Chất liệu", "Kích thước", "Màu sắc", "Giá", "Số lượng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSPCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSPCTMouseClicked(evt);
            }
        });
        spSPCT.setViewportView(tblSPCT);
        if (tblSPCT.getColumnModel().getColumnCount() > 0) {
            tblSPCT.getColumnModel().getColumn(0).setPreferredWidth(40);
            tblSPCT.getColumnModel().getColumn(8).setPreferredWidth(40);
        }

        btnThemSP.setBackground(new java.awt.Color(172, 182, 229));
        btnThemSP.setForeground(new java.awt.Color(245, 245, 245));
        btnThemSP.setText("Thêm sản phẩm");
        btnThemSP.setRippleColor(new java.awt.Color(255, 255, 255));
        btnThemSP.setShadowColor(new java.awt.Color(172, 182, 229));
        btnThemSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemSPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnThemSP, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(spSPCT))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(btnThemSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(spSPCT, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE))
        );

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel8.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 6, 210, 180));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Đơn hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Thông tin khách hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 11))); // NOI18N

        btnChoKH.setBackground(new java.awt.Color(172, 182, 229));
        btnChoKH.setForeground(new java.awt.Color(245, 245, 245));
        btnChoKH.setText("Chọn");
        btnChoKH.setRippleColor(new java.awt.Color(255, 255, 255));
        btnChoKH.setShadowColor(new java.awt.Color(172, 182, 229));
        btnChoKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChoKHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnChoKH, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(btnChoKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel3.add(jPanel7);

        btnThem4.setBackground(new java.awt.Color(172, 182, 229));
        btnThem4.setForeground(new java.awt.Color(245, 245, 245));
        btnThem4.setText("Làm mới");
        btnThem4.setRippleColor(new java.awt.Color(255, 255, 255));
        btnThem4.setShadowColor(new java.awt.Color(172, 182, 229));
        jPanel3.add(btnThem4);

        addKhung.setBackground(new java.awt.Color(116, 235, 213));
        addKhung.setForeground(new java.awt.Color(245, 245, 245));
        addKhung.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/MMT_Shop/icon/Bribery_1.png"))); // NOI18N
        addKhung.setText("Thanh toán");
        addKhung.setRippleColor(new java.awt.Color(255, 255, 255));
        addKhung.setShadowColor(new java.awt.Color(116, 235, 213));
        jPanel3.add(addKhung);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1075, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnThem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThem3ActionPerformed

    }//GEN-LAST:event_btnThem3ActionPerformed

    private void tblSPCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSPCTMouseClicked


    }//GEN-LAST:event_tblSPCTMouseClicked

    private void btnChoKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChoKHActionPerformed

    }//GEN-LAST:event_btnChoKHActionPerformed

    private void tblHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHoaDonMouseClicked
        clickHD();

    }//GEN-LAST:event_tblHoaDonMouseClicked

    private void btnThemSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSPActionPerformed
        soLuong = JOptionPane.showInputDialog("nhập số lượng", "");
        int row = tblSPCT.getSelectedRow();
        int soLuongBD = Integer.valueOf(tblSPCT.getValueAt(row, 9).toString());
        soLuongTon = String.valueOf(soLuongBD - Integer.valueOf(sl));
        insertHDCT();
    }//GEN-LAST:event_btnThemSPActionPerformed

    private void btnXoaSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaSPActionPerformed

    }//GEN-LAST:event_btnXoaSPActionPerformed

    private void tblHDCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHDCTMouseClicked

    }//GEN-LAST:event_tblHDCTMouseClicked

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        DefaultTableModel ob = (DefaultTableModel) tblSPCT.getModel();
        TableRowSorter<DefaultTableModel> obj = new TableRowSorter<>(ob);
        tblSPCT.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(txtTimKiem.getText()));
    }//GEN-LAST:event_txtTimKiemKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.MMT_Shop.swing.button.Button addKhung;
    private com.MMT_Shop.swing.button.Button btnChoKH;
    private com.MMT_Shop.swing.button.Button btnThem3;
    private com.MMT_Shop.swing.button.Button btnThem4;
    private com.MMT_Shop.swing.button.Button btnThemSP;
    private com.MMT_Shop.swing.button.Button btnXoaSP;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane spHD;
    private javax.swing.JScrollPane spHDCT;
    private javax.swing.JScrollPane spSPCT;
    private com.MMT_Shop.swing.Table tblHDCT;
    private com.MMT_Shop.swing.Table tblHoaDon;
    private com.MMT_Shop.swing.Table tblSPCT;
    // End of variables declaration//GEN-END:variables

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Thread newThread(Runnable r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
