/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.MMT_Shop.ngan;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class Form_table extends javax.swing.JPanel {

    static String maNV;

    NhanVienService service = new NhanVienService();
    List<NhanVien> listNhanVien = new ArrayList<>();
    private int indexRowChoice = 0;
    DefaultTableModel dtm = new DefaultTableModel();
    ArrayList<NhanVien> list = service.selectAll();
    boolean trangThai;
    MsgBox msgBox = new MsgBox();

    public static String MANV;

    public Form_table() {
        initComponents();
        fillToTable();

    }

    private void showData() {
        int row = tblNhanVien1.getSelectedRow();

        // Check if a row is selected
        if (row >= 0) {
            MANV = tblNhanVien1.getValueAt(row, 1).toString();
            // Perform actions with MANV or display it as needed
        } else {
            // Handle the case where no row is selected, e.g., show a message to the user
            System.out.println("No row selected");
        }
    }

    public void nhanVien() {
        int row = tblNhanVien1.getSelectedRow();

        trangThai = tblNhanVien1.getValueAt(row, 9).toString() == "Đang làm" ? false : true;
    }

    public void fillToTable() {
        listNhanVien = service.selectAll();
        System.out.println(listNhanVien);
        DefaultTableModel model = (DefaultTableModel) tblNhanVien1.getModel();
        model.setRowCount(0);
        listNhanVien.forEach(s -> model.addRow(new Object[]{tblNhanVien1.getRowCount() + 1,
            s.getMaNV(), s.getHoTen(), s.getSdt(), s.getEmail(), s.isGioiTinh() == true ? "Nam" : "Nữ", s.getSoCMND(), s.getDiaChi(), s.getNgaySinh(), s.isTrangThai() == false ? "Đang làm" : "Đã nghỉ"}));
        tblNhanVien1.setModel(model);
    }

    private void setForm(JPanel com) {
        p3.removeAll();
        p3.add(com);
        p3.repaint();
        p3.revalidate();
    }

    public void loatdate(ArrayList<NhanVien> list) {
        dtm = (DefaultTableModel) tblNhanVien1.getModel();
        dtm.setRowCount(0);
        // int i = 0;
        for (NhanVien s : list) {
            // i++;
            dtm.addRow(new Object[]{
                tblNhanVien1.getRowCount() + 1,
                s.getMaNV(), s.getHoTen(), s.getSdt(), s.getEmail(), s.isGioiTinh() == true ? "Nam" : "Nữ", s.getSoCMND(), s.getDiaChi(), s.getNgaySinh(), s.isTrangThai() == false ? "Đang làm" : "Đã nghỉ"
            });

        }
        //  fillToTable();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        p3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblNhanVien1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        txtTimKiem1 = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));

        p3.setBackground(new java.awt.Color(255, 255, 255));
        p3.setLayout(new java.awt.BorderLayout());

        tblNhanVien1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblNhanVien1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "MaNV", "Tên NV", "SDT", "Email", "GioiTinh", "CCCD", "Địa Chỉ", "Ngày Sinh", "Trạng Thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhanVien1.setRowHeight(30);
        tblNhanVien1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhanVien1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblNhanVien1MousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblNhanVien1);

        p3.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tìm kiếm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N

        txtTimKiem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiem1ActionPerformed(evt);
            }
        });
        txtTimKiem1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiem1KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(txtTimKiem1, javax.swing.GroupLayout.DEFAULT_SIZE, 783, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        p3.add(jPanel4, java.awt.BorderLayout.PAGE_START);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(p3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(p3, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void tblNhanVien1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVien1MouseClicked
        if (evt.getClickCount() == 2) {
            showData();

            setForm(new Form_Update1());
            nhanVien();

        }

    }//GEN-LAST:event_tblNhanVien1MouseClicked

    private void tblNhanVien1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVien1MousePressed

    }//GEN-LAST:event_tblNhanVien1MousePressed

    private void txtTimKiem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiem1ActionPerformed

//        clear();
    }//GEN-LAST:event_txtTimKiem1ActionPerformed

    private void txtTimKiem1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiem1KeyReleased
        listNhanVien.clear();
        ArrayList<NhanVien> listNV = new ArrayList<>();

        for (NhanVien nhanVien : list) {

            String timkiem = txtTimKiem1.getText();
            String masdt = nhanVien.getSdt() + "";

            if (masdt.startsWith(txtTimKiem1.getText())) {
                listNV.add(nhanVien);
            }

            String ngayString = nhanVien.getNgaySinh() + "";

            if (ngayString.startsWith(txtTimKiem1.getText())) {
                listNV.add(nhanVien);
            }
            String ten = nhanVien.getHoTen() + "";

            if (ten.startsWith(txtTimKiem1.getText().trim())) {
                listNV.add(nhanVien);
            }
            String ma = nhanVien.getMaNV() + "";

            if (ma.startsWith(txtTimKiem1.getText().trim())) {
                listNV.add(nhanVien);
            }
            String diachi = nhanVien.getDiaChi() + "";

            if (diachi.startsWith(txtTimKiem1.getText().trim())) {
                listNV.add(nhanVien);
            }
            String cccd = nhanVien.getSoCMND() + "";

            if (cccd.startsWith(txtTimKiem1.getText().trim())) {
                listNV.add(nhanVien);
            }
            

        }
        if (txtTimKiem1.getText().equalsIgnoreCase("")) {
            loatdate(list);
        } else {

            loatdate(listNV);
        }
    }//GEN-LAST:event_txtTimKiem1KeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel p3;
    private javax.swing.JTable tblNhanVien1;
    private javax.swing.JTextField txtTimKiem1;
    // End of variables declaration//GEN-END:variables
}
