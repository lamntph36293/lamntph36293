package com.MMT_Shop.swing.ButtonTable;

/**
 *
 * @author RAVEN
 */
public interface TableActionEvent {


    public void onDelete(int row);

    public void onView(int row);
}
